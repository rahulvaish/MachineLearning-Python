# House-price
Predict the sale price of house with more explanation.

[Download dataset](https://www.kaggle.com/c/house-prices-advanced-regression-techniques/data)
